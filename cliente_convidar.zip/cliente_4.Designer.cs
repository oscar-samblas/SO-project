﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserBox = new System.Windows.Forms.TextBox();
            this.PassBox = new System.Windows.Forms.TextBox();
            this.Usuario = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.Label();
            this.Registro = new System.Windows.Forms.Button();
            this.Login = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LogOut = new System.Windows.Forms.Button();
            this.Request = new System.Windows.Forms.Button();
            this.DIA = new System.Windows.Forms.RadioButton();
            this.GridListaConectados = new System.Windows.Forms.DataGridView();
            this.LabelLista = new System.Windows.Forms.Label();
            this.Invitar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridListaConectados)).BeginInit();
            this.SuspendLayout();
            // 
            // UserBox
            // 
            this.UserBox.Location = new System.Drawing.Point(160, 145);
            this.UserBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.UserBox.Name = "UserBox";
            this.UserBox.Size = new System.Drawing.Size(111, 22);
            this.UserBox.TabIndex = 0;
            // 
            // PassBox
            // 
            this.PassBox.Location = new System.Drawing.Point(160, 183);
            this.PassBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PassBox.Name = "PassBox";
            this.PassBox.Size = new System.Drawing.Size(111, 22);
            this.PassBox.TabIndex = 1;
            // 
            // Usuario
            // 
            this.Usuario.AutoSize = true;
            this.Usuario.Location = new System.Drawing.Point(9, 145);
            this.Usuario.Name = "Usuario";
            this.Usuario.Size = new System.Drawing.Size(129, 17);
            this.Usuario.TabIndex = 2;
            this.Usuario.Text = "Nombre de usuario";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(9, 188);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(69, 17);
            this.Password.TabIndex = 3;
            this.Password.Text = "Password";
            // 
            // Registro
            // 
            this.Registro.Location = new System.Drawing.Point(155, 225);
            this.Registro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Registro.Name = "Registro";
            this.Registro.Size = new System.Drawing.Size(116, 23);
            this.Registro.TabIndex = 4;
            this.Registro.Text = "REGISTER";
            this.Registro.UseVisualStyleBackColor = true;
            this.Registro.Click += new System.EventHandler(this.Registro_Click);
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(81, 305);
            this.Login.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(127, 28);
            this.Login.TabIndex = 5;
            this.Login.Text = "LOGIN";
            this.Login.UseVisualStyleBackColor = true;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(197, 114);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(28, 25);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // LogOut
            // 
            this.LogOut.AutoSize = true;
            this.LogOut.Location = new System.Drawing.Point(81, 305);
            this.LogOut.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(127, 28);
            this.LogOut.TabIndex = 8;
            this.LogOut.Text = "LOG OUT";
            this.LogOut.UseVisualStyleBackColor = true;
            this.LogOut.Visible = false;
            this.LogOut.Click += new System.EventHandler(this.button2_Click);
            // 
            // Request
            // 
            this.Request.Location = new System.Drawing.Point(395, 82);
            this.Request.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Request.Name = "Request";
            this.Request.Size = new System.Drawing.Size(157, 39);
            this.Request.TabIndex = 9;
            this.Request.Text = "ENVIAR PETICION";
            this.Request.UseVisualStyleBackColor = true;
            this.Request.Click += new System.EventHandler(this.Request_Click);
            // 
            // DIA
            // 
            this.DIA.AutoSize = true;
            this.DIA.Location = new System.Drawing.Point(312, 20);
            this.DIA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DIA.Name = "DIA";
            this.DIA.Size = new System.Drawing.Size(366, 21);
            this.DIA.TabIndex = 10;
            this.DIA.TabStop = true;
            this.DIA.Text = "(WIP) Consultar jugadores que jugaron el 29/05/2021";
            this.DIA.UseVisualStyleBackColor = true;
            // 
            // GridListaConectados
            // 
            this.GridListaConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridListaConectados.Location = new System.Drawing.Point(557, 188);
            this.GridListaConectados.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.GridListaConectados.Name = "GridListaConectados";
            this.GridListaConectados.Size = new System.Drawing.Size(317, 174);
            this.GridListaConectados.TabIndex = 11;
            this.GridListaConectados.Visible = false;
            this.GridListaConectados.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridListaConectados_CellClick);
            // 
            // LabelLista
            // 
            this.LabelLista.AutoSize = true;
            this.LabelLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelLista.Location = new System.Drawing.Point(553, 147);
            this.LabelLista.Name = "LabelLista";
            this.LabelLista.Size = new System.Drawing.Size(179, 20);
            this.LabelLista.TabIndex = 12;
            this.LabelLista.Text = "Lista de conectados";
            this.LabelLista.Visible = false;
            this.LabelLista.Click += new System.EventHandler(this.LabelLista_Click);
            // 
            // Invitar
            // 
            this.Invitar.Location = new System.Drawing.Point(799, 147);
            this.Invitar.Name = "Invitar";
            this.Invitar.Size = new System.Drawing.Size(75, 23);
            this.Invitar.TabIndex = 13;
            this.Invitar.Text = "INVITAR";
            this.Invitar.UseVisualStyleBackColor = true;
            this.Invitar.Click += new System.EventHandler(this.Invitar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 382);
            this.Controls.Add(this.Invitar);
            this.Controls.Add(this.LabelLista);
            this.Controls.Add(this.GridListaConectados);
            this.Controls.Add(this.DIA);
            this.Controls.Add(this.Request);
            this.Controls.Add(this.LogOut);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.Registro);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Usuario);
            this.Controls.Add(this.PassBox);
            this.Controls.Add(this.UserBox);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridListaConectados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox UserBox;
        private System.Windows.Forms.TextBox PassBox;
        private System.Windows.Forms.Label Usuario;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Button Registro;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button LogOut;
        private System.Windows.Forms.Button Request;
        private System.Windows.Forms.RadioButton DIA;
        private System.Windows.Forms.Label LabelLista;
        private System.Windows.Forms.DataGridView GridListaConectados;
        private System.Windows.Forms.Button Invitar;
    }
}

