﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        int PORT = 9040;
        int conectado;
        string UsuarioGuardado;
        delegate void DelegadoLista(string[] Conectados, bool Visible);
        delegate void DelegadoVisibilidad(bool Visible);
        
        string inv_Text;
        List<string> Conectados = new List<string>();
        int totalPartidas;
        int IDPARTIDA;
        string R_SI_NO;

        public Form1()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
        }
        public void Connectar_Servidor()
        {
            if (conectado == 0)
            {
                try
                {
                    //Conectem al servidor
                    IPAddress address = IPAddress.Parse("192.168.56.101");
                    IPEndPoint endPoint = new IPEndPoint(address, PORT);

                    server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    try
                    {
                        server.Connect(endPoint);
                        conectado = 1;
                        ThreadStart ts = delegate { AtenderServidor(); };
                        atender = new Thread(ts);
                        atender.Start();
                    }
                    catch (SocketException error)
                    {
                        conectado = 0;
                        MessageBox.Show("No se ha podido conectar al servidor");
                        return;
                    }
                    pictureBox1.BackColor = Color.Green;
                }
                catch
                {
                    MessageBox.Show("No se ha podido conectar con el servidor");
                }
            }
            else     //conectado = 1, estamos conectados
                MessageBox.Show("Ya estas conectado");
        }

        public void Desconexion()
        {
            string[] temp = new string[0];
            ActualizarListaConectados(temp, false);
            CambioVisibilidad(false);
            if (conectado == 1)
            {
                conectado = 0;
                pictureBox1.BackColor = Color.Gray;
                UserBox.Text = "";
                PassBox.Text = "";
                if (UsuarioGuardado != null)
                {
                    string mensaje = "0/" + "1" + "/" + UsuarioGuardado;
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                    server.Shutdown(SocketShutdown.Both);
                    UsuarioGuardado = null;
                    server.Close();
                }
                else
                {
                    string mensaje = "0/" + "0";
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                    server.Send(msg);
                    server.Shutdown(SocketShutdown.Both);
                    server.Close();
                }
                atender.Abort();
            }
            else
            {
                pictureBox1.BackColor = Color.Gray;
                MessageBox.Show("Ya estas desconectado");
            }

        }

        private void Login_Click(object sender, EventArgs e)
        {
            Connectar_Servidor();
            Login_Peticion();
        }

        public void Login_Peticion()
        {
            if (conectado == 1)
            {
                //Conectamos al usuario y enviamos los datos al servidor
                string peticion = "1/" + UserBox.Text + "/" + PassBox.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(peticion);
                server.Send(msg);
            }
            else
                MessageBox.Show("No estas conectado");
        }

        public void Login_Respuesta(int codigo)
        {
            try
            {
                if (codigo == 2)
                {
                    UsuarioGuardado = UserBox.Text;
                    MessageBox.Show("Login succesful");
                    pictureBox1.BackColor = Color.Yellow;

                }

                else if (codigo == 1)
                {
                    MessageBox.Show("Usuario no registrado");
                    pictureBox1.BackColor = Color.Blue;
                }

                else if (codigo == 3)//usuario existe pero no coincide con la contraseña
                {
                    MessageBox.Show("Contraseña incorrecta");
                    pictureBox1.BackColor = Color.Red;
                }

                else
                {
                    MessageBox.Show("Ha habido un error");
                }
            }
            catch
            {
                MessageBox.Show("Error");
            }
        }

        private void button2_Click(object sender, EventArgs e)  //Desconectamos
        {
            Desconexion();
        }

        private void Registro_Click(object sender, EventArgs e)
        {

            Connectar_Servidor();
            Registro_Peticion();
            Usuario.Text = "";
            Password.Text = "";
        }

        public void Registro_Peticion()
        {
            string peticion = "2/" + UserBox.Text + "/" + PassBox.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(peticion);
            server.Send(msg);
        }

        public void Registro_Respuesta()
        {
            MessageBox.Show("Usuario registrado");
        }

        private void Request_Click(object sender, EventArgs e)
        {
            if (DIA.Checked)
            {
                string peticion = "/6";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(peticion);
                server.Send(msg);

                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string respuesta = Encoding.ASCII.GetString(msg2).Split('\0')[0];

                MessageBox.Show("El numero de jugadores que jugaron el 29/05/2021 es " + respuesta);
            }

        }

        public void RecibeInvitacionPartida(string invitacion)
        {
            string[] inv = invitacion.Split(',');
            int idPartida = Convert.ToInt32(inv[1]); //La 2a posicion de la respuesta es la idP
            inv_Text = inv[0] + " te ha invitado a jugar";  //el organizador es el primero que entra en la sala
            Invitacion invi = new Invitacion();
            invi.ShowDialog();                              //Abrimos formulario para responder a la invitacion
            
            string r = invi.TomaRespuesta().ToString();     //Obtenemos la respuesta a la invitacion
            DameRespuesta_SI_NO(r);
            string req = ("6/" + Convert.ToString(idPartida) + "/" + R_SI_NO);
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(req);      //Peticion: 6/4/SI
            server.Send(msg);

        }                   //V4

        public void DameRespuesta_SI_NO(string r)
        {
            this.R_SI_NO = r;           //Getter: obtenemos la respuesta desde el formulario invitacion
        }                               //V4

        public void DameNombresListaConectados(List<string> Conectados)
        {
            for (int i = 0; i<GridListaConectados.RowCount-1; i++)
            {
                Conectados.Add(GridListaConectados.Rows[i].Cells[0].Value.ToString());
            }
        }

        private void AtenderServidor()
        {
            while (true)
            {
                string mensaje;
                byte[] msg2 = new byte[120];
                server.Receive(msg2);
                mensaje = msg2.ToString();
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                string[] trozos2;
                DelegadoLista delegadoLista = new DelegadoLista(ActualizarListaConectados);
                DelegadoVisibilidad delegadoVisibilidad = new DelegadoVisibilidad(CambioVisibilidad);
                switch (codigo)
                {
                    case 0://Desconexion
                        Desconexion();
                        break;
                    case 1:                     //Login: Usuario no registrado
                        Login_Respuesta(codigo);
                        break;
                    case 2:                     //Login con exito
                        Login_Respuesta(codigo);
                        LabelLista.Invoke(delegadoVisibilidad, new object[] { true });
                        break;
                    case 3:                     //Login : Contraseña incorrecta
                        Login_Respuesta(codigo);
                        break;
                    case 4:
                        Registro_Respuesta();
                        break;
                    case 99:
                        mensaje = trozos[1].Split('\0')[0];
                        trozos2 = mensaje.Split('-');
                        GridListaConectados.Invoke(delegadoLista, new object[] { trozos2, true }); ;
                        DameNombresListaConectados(Conectados);
                        break;
                    case 5:           //Te invitan a una partida
                        RecibeInvitacionPartida(mensaje);
                        break;
                    case 6:           //Respuesta SI / NO a la invitacion
                        string invitada;
                        invitada = trozos[2].ToString();
                        IDPARTIDA = Convert.ToInt32(trozos[1]);
                        if (trozos[3] == "SI")      //nos falta
                        {
                        }
                        else
                        {
                        }
                        break;
                }
            }
        }                                           //V4 Modificado
        private void ActualizarListaConectados(string[] nombres, bool Visible)
        {
            for (int i = 0; i < nombres.Length; i++)
            {
                GridListaConectados.RowCount = nombres.Length;
                GridListaConectados.ColumnCount = 1;
                GridListaConectados.Rows[i].Cells[0].Value = nombres[i];
            }
            if (Visible == false)
            {
                GridListaConectados.Visible = false;
            }
            else
            {
                GridListaConectados.Visible = true;
            }
        }
        private void CambioVisibilidad(bool Visible)
        {
            if (Visible == false)
            {
                GridListaConectados.Visible = false;
                LabelLista.Visible = false;
                LogOut.Visible = false;
                Invitar.Visible = false;
                Login.Visible = true;
            }
            else
            {
                GridListaConectados.Visible = true;
                LabelLista.Visible = true;
                LogOut.Visible = true;
                Invitar.Visible = true;
                Login.Visible = false;
            }
        }
        private void CambioVisibilidadLabel(bool Visible)
        {
            if (Visible == true)
            {
                LabelLista.Visible = true;
            }
            else
            {
                LabelLista.Visible = false;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LabelLista_Click(object sender, EventArgs e)
        {

        }

        private void Invitar_Click(object sender, EventArgs e)
        {
            int fila = 0;
            int i = 0;
            int m = 1;
            int numFilasSeleccionadas = GridListaConectados.SelectedRows.Count;
            string[] seleccionados = new string[100];
            while (i < GridListaConectados.RowCount-1)  //Añadimos a seleccionados los jugadores conectados del grid view
            {
                if (GridListaConectados.Rows[fila].Cells[0].Style.BackColor == Color.Yellow)
                {
                    seleccionados[m] = Conectados[i];   //m = 1 pq se suma la que organiza (quien invita)
                    GridListaConectados.Rows[fila].Cells[0].Style.BackColor = Color.White;
                    fila++;
                    m++;
                }
                i++;
            }

            if (seleccionados[0] != null)       //si hemos seleccionado jugadores
            {                                   //hacemos la peticion
                totalPartidas++;
                IDPARTIDA = totalPartidas + 1;
                string request = "5/" + Convert.ToString(IDPARTIDA);
                int n = 0;
                while (n < Conectados.Count)
                {
                    request = request + "/" + Conectados[n];    //peticion tipo: 5/4/Juan/Ana/Maria
                }
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(request);
                server.Send(msg);
            }
            else
                MessageBox.Show("Selecciona a jugadores conectados primero");
        }                  //V4

        private void GridListaConectados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (GridListaConectados.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor == Color.White)
            {
                GridListaConectados.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.Yellow;
            }
            else 
            {
                 GridListaConectados.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.White;
            }
        }       //V4: Seleccionar fila del GridView
    }
}
